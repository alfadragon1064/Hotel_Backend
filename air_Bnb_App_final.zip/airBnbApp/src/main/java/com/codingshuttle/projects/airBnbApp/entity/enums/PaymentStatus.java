package com.codingshuttle.projects.airBnbApp.entity.enums;

public enum PaymentStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
