package com.codingshuttle.projects.airBnbApp.entity.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
