package com.codingshuttle.projects.airBnbApp.entity.enums;

public enum Role {
    GUEST,
    HOTEL_MANAGER
}
