package com.codingshuttle.projects.airBnbApp.dto;

import lombok.Data;

@Data
public class LoginDto {
    private String email;
    private String password;
}
